function visData = sc_vis_planar_structure(modelPlane, modelReg)
%
%     sc_vis_planar_structure: 
%     visualize the extracted planar structure

%% 
visData = [];



end