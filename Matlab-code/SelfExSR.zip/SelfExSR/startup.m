% STARTUP

% Add path to source code
addpath('source');
addpath(genpath('external'));
clc