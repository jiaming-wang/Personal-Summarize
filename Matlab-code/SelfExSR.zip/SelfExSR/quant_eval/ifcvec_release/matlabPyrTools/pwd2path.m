% PWD2PATH()
%
% add current working directory (pwd) to path.

P = path;
path(pwd,P);
